# Bunkerweb paths template files
"error.html"  ->  "/usr/share/bunkerweb/core/errors/files/error.html"
"default.html"  ->  "/usr/share/bunkerweb/core/misc/files/default.html"